# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.29)
# Database: rhinoceros
# Generation Time: 2013-08-30 09:06:15 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table _admin_rec_home
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_admin_rec_home`;

CREATE TABLE `_admin_rec_home` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `pid_sort` int(11) DEFAULT NULL,
  `nid` int(11) DEFAULT NULL,
  `nid_sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _admin_rec_home.bak
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_admin_rec_home.bak`;

CREATE TABLE `_admin_rec_home.bak` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `pid_sort` int(11) DEFAULT NULL,
  `nid` int(11) DEFAULT NULL,
  `nid_sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _apply_permission_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_apply_permission_log`;

CREATE TABLE `_apply_permission_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `douban_id` varchar(11) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `reason` text NOT NULL,
  `result` tinyint(2) DEFAULT '-2' COMMENT '-2未处理/-1已移除/0已否决/1已通过',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operator` int(11) DEFAULT '1' COMMENT '操作者id',
  `operating_ts` timestamp NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _confirm_email
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_confirm_email`;

CREATE TABLE `_confirm_email` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `douban_id` varchar(11) DEFAULT NULL COMMENT '豆瓣ID',
  `email` varchar(100) DEFAULT NULL,
  `token` char(100) DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `creation_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _feedback
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_feedback`;

CREATE TABLE `_feedback` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `douban_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _node
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_node`;

CREATE TABLE `_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nodeName` tinytext NOT NULL,
  `nodeDesc` text,
  `nodeImg` varchar(100) DEFAULT NULL,
  `postMount` int(8) NOT NULL DEFAULT '0' COMMENT '多少文章',
  `nodeOpen` int(1) NOT NULL DEFAULT '1' COMMENT '是否开放',
  `node_author` int(11) NOT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='话题节点';



# Dump of table _nodeLinkPost
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_nodeLinkPost`;

CREATE TABLE `_nodeLinkPost` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nodeID` int(11) NOT NULL COMMENT '话题节点名称',
  `postID` int(11) NOT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _notification
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_notification`;

CREATE TABLE `_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL COMMENT '针对谁id做了动作',
  `uid` int(11) NOT NULL COMMENT '产生行为的用户id',
  `mention_id` int(11) DEFAULT NULL COMMENT '@用户id',
  `pid` int(11) DEFAULT NULL COMMENT '片段ID',
  `nid` int(11) DEFAULT NULL COMMENT '话题ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:评论 2:喜欢 3:回复',
  `isread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已读',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _notification_mention
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_notification_mention`;

CREATE TABLE `_notification_mention` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `nid` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '3',
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_permission`;

CREATE TABLE `_permission` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `douban_id` varchar(11) NOT NULL DEFAULT '' COMMENT '豆瓣ID',
  `rights` int(11) DEFAULT '0' COMMENT '权限',
  `operator` int(11) DEFAULT '0',
  `operating_ts` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _post
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_post`;

CREATE TABLE `_post` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '片段ID',
  `nodeId` int(8) NOT NULL COMMENT '属于哪个Node',
  `postTemp` int(1) NOT NULL COMMENT '所用模板',
  `postImage` varchar(120) DEFAULT NULL COMMENT '片段图片',
  `postTitle` tinytext NOT NULL COMMENT '片段名称',
  `postCaption` text COMMENT '片段简介',
  `postArticle` text COMMENT '片段正文',
  `postAuthor` int(8) NOT NULL COMMENT '作者ID',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `magnitude` int(11) NOT NULL DEFAULT '0' COMMENT '实际得票数',
  `score` float NOT NULL DEFAULT '0' COMMENT '最终得票',
  `comment_num` int(11) DEFAULT '0' COMMENT '评论数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _post_comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_post_comments`;

CREATE TABLE `_post_comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `content` text NOT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图片评论';



# Dump of table _post_vote_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_post_vote_user`;

CREATE TABLE `_post_vote_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `creation_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table _post.bak
# ------------------------------------------------------------

DROP TABLE IF EXISTS `_post.bak`;

CREATE TABLE `_post.bak` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '片段ID',
  `nodeId` int(8) NOT NULL COMMENT '属于哪个Node',
  `postTemp` int(1) NOT NULL COMMENT '所用模板',
  `postImage` varchar(120) DEFAULT NULL COMMENT '片段图片',
  `postTitle` tinytext NOT NULL COMMENT '片段名称',
  `postCaption` text COMMENT '片段简介',
  `postArticle` text COMMENT '片段正文',
  `postAuthor` int(8) NOT NULL COMMENT '作者ID',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `magnitude` int(11) NOT NULL DEFAULT '0' COMMENT '实际得票数',
  `score` float NOT NULL DEFAULT '0' COMMENT '最终得票',
  `comment_num` int(11) DEFAULT '0' COMMENT '评论数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table image
# ------------------------------------------------------------

DROP TABLE IF EXISTS `image`;

CREATE TABLE `image` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '图片ID',
  `path` tinytext NOT NULL COMMENT '图片地址',
  `imageTitle` tinytext NOT NULL COMMENT '图片标题',
  `imageDescribe` tinytext COMMENT '图片描述',
  `userID` mediumint(8) NOT NULL COMMENT '所属用户ID',
  `favo_num` int(11) NOT NULL COMMENT '喜欢数',
  `view_num` int(11) NOT NULL DEFAULT '0' COMMENT '查看数',
  `comm_num` int(11) NOT NULL COMMENT '评论数',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图片';



# Dump of table ImageComments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ImageComments`;

CREATE TABLE `ImageComments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `comment` text,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `applicant_id` (`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图片评论';



# Dump of table ImageFavorite
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ImageFavorite`;

CREATE TABLE `ImageFavorite` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `img_id` int(11) NOT NULL COMMENT '图片ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图片喜欢';



# Dump of table ImageViewUsers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ImageViewUsers`;

CREATE TABLE `ImageViewUsers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `image_id` int(11) NOT NULL COMMENT '图片ID',
  `user_id` int(11) NOT NULL COMMENT '查看过此图片的用户ID',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '查看时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='查看过某张图片的用户';



# Dump of table PasswordResetToken
# ------------------------------------------------------------

DROP TABLE IF EXISTS `PasswordResetToken`;

CREATE TABLE `PasswordResetToken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL COMMENT '邮箱地址',
  `timestamp` double NOT NULL COMMENT '时间戳',
  `token` varchar(40) NOT NULL COMMENT '口令',
  `valid` int(2) NOT NULL COMMENT '验证',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `session_id` char(128) NOT NULL,
  `atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data` text,
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table UserProfile
# ------------------------------------------------------------

DROP TABLE IF EXISTS `UserProfile`;

CREATE TABLE `UserProfile` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `city` tinytext COMMENT '常居城市',
  `bio` text COMMENT '简介',
  `email_subscribe` tinyint(1) DEFAULT '1' COMMENT '是否开启邮件提醒',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户资料';



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `douban_id` varchar(11) DEFAULT NULL COMMENT '豆瓣ID',
  `username` varchar(30) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` char(35) DEFAULT NULL,
  `nickname` varchar(35) NOT NULL,
  `authKey` char(32) DEFAULT NULL,
  `ipAddress` varchar(30) NOT NULL,
  `joinTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `avatarPath` tinytext COMMENT '用户头像',
  `nicknameChangeTime` timestamp NULL DEFAULT NULL COMMENT '昵称修改时间',
  `via` int(2) NOT NULL DEFAULT '0' COMMENT '注册来源',
  `rights` int(11) DEFAULT '0' COMMENT '权限',
  `close` int(11) DEFAULT '0' COMMENT '是否关闭账号',
  `lastLoginTime` timestamp NULL DEFAULT NULL,
  `lastLoginIP` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
